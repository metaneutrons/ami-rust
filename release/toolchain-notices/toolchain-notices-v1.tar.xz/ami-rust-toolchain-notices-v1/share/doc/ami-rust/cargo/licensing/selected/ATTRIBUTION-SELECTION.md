# Selected license text and package author metadata

The authors below are copied from each registry package Cargo.toml. They are package metadata, not a new or inferred copyright notice. Existing upstream license, copyright, AUTHORS, and README bytes are preserved in `registry/` or `licence-review/`. No copyright year or holder was manufactured.

The selected choice is MIT where the package metadata offers MIT; `vec_mut_scan` is 0BSD. Where objc2-family crates, `block2`, or `dispatch2` provide only the shared scope statement, the accompanying MIT file is the generic SPDX template and still has placeholders. It must not be treated as an upstream attribution.

| Package | Declared license | Cargo.toml authors | Selected text |
|---|---|---|---|
| `anes 0.1.6` | `MIT OR Apache-2.0` | Robert Vojta <rvojta@me.com> | `MIT` — LICENSE-MIT |
| `block2 0.6.2` | `MIT` | Mads Marquart <mads@marquart.dk> | `MIT` — SPDX MIT template (placeholder text; no full upstream terms found) |
| `defmt-parser 1.0.0` | `MIT OR Apache-2.0` | The Knurling-rs developers | `MIT` — LICENSE-MIT |
| `dispatch2 0.3.1` | `Zlib OR Apache-2.0 OR MIT` | Mads Marquart <mads@marquart.dk>; Mary <mary@mary.zone> | `MIT` — SPDX MIT template (placeholder text; no full upstream terms found) |
| `objc2 0.6.4` | `MIT` | Mads Marquart <mads@marquart.dk> | `MIT` — SPDX MIT template (placeholder text; no full upstream terms found) |
| `objc2-cloud-kit 0.3.2` | `Zlib OR Apache-2.0 OR MIT` | No authors field | `MIT` — SPDX MIT template (placeholder text; no full upstream terms found) |
| `objc2-core-data 0.3.2` | `Zlib OR Apache-2.0 OR MIT` | No authors field | `MIT` — SPDX MIT template (placeholder text; no full upstream terms found) |
| `objc2-core-foundation 0.3.2` | `Zlib OR Apache-2.0 OR MIT` | No authors field | `MIT` — SPDX MIT template (placeholder text; no full upstream terms found) |
| `objc2-core-graphics 0.3.2` | `Zlib OR Apache-2.0 OR MIT` | No authors field | `MIT` — SPDX MIT template (placeholder text; no full upstream terms found) |
| `objc2-core-image 0.3.2` | `Zlib OR Apache-2.0 OR MIT` | No authors field | `MIT` — SPDX MIT template (placeholder text; no full upstream terms found) |
| `objc2-core-location 0.3.2` | `Zlib OR Apache-2.0 OR MIT` | No authors field | `MIT` — SPDX MIT template (placeholder text; no full upstream terms found) |
| `objc2-core-text 0.3.2` | `Zlib OR Apache-2.0 OR MIT` | No authors field | `MIT` — SPDX MIT template (placeholder text; no full upstream terms found) |
| `objc2-encode 4.1.0` | `MIT` | Mads Marquart <mads@marquart.dk> | `MIT` — SPDX MIT template (placeholder text; no full upstream terms found) |
| `objc2-foundation 0.3.2` | `MIT` | No authors field | `MIT` — SPDX MIT template (placeholder text; no full upstream terms found) |
| `objc2-io-surface 0.3.2` | `Zlib OR Apache-2.0 OR MIT` | No authors field | `MIT` — SPDX MIT template (placeholder text; no full upstream terms found) |
| `objc2-quartz-core 0.3.2` | `Zlib OR Apache-2.0 OR MIT` | No authors field | `MIT` — SPDX MIT template (placeholder text; no full upstream terms found) |
| `objc2-ui-kit 0.3.2` | `Zlib OR Apache-2.0 OR MIT` | No authors field | `MIT` — SPDX MIT template (placeholder text; no full upstream terms found) |
| `objc2-user-notifications 0.3.2` | `Zlib OR Apache-2.0 OR MIT` | No authors field | `MIT` — SPDX MIT template (placeholder text; no full upstream terms found) |
| `r-efi 5.3.0` | `MIT OR Apache-2.0 OR LGPL-2.1-or-later` | No authors field | `MIT` — AUTHORS |
| `r-efi 6.0.0` | `MIT OR Apache-2.0 OR LGPL-2.1-or-later` | No authors field | `MIT` — AUTHORS |
| `rsqlite-vfs 0.1.1` | `MIT` | No authors field | `MIT` — LICENSE |
| `valuable 0.1.1` | `MIT` | No authors field | `MIT` — LICENSE |
| `vec_mut_scan 0.3.0` | `0BSD` | Jannis Harder <me@jix.one> | `0BSD` — COPYRIGHT |
| `winapi-i686-pc-windows-gnu 0.4.0` | `MIT/Apache-2.0` | Peter Atashian <retep998@gmail.com> | `MIT` — LICENSE-MIT |
| `winapi-x86_64-pc-windows-gnu 0.4.0` | `MIT/Apache-2.0` | Peter Atashian <retep998@gmail.com> | `MIT` — LICENSE-MIT |

This capsule is a source and notice record. It is not legal clearance or product-release acceptance. The objc2 `LICENSE.md` source-caveat bytes and the selected MIT/0BSD texts are retained in the evidence tree.