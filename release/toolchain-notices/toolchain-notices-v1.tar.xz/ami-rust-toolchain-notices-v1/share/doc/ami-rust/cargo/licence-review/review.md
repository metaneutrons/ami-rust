# R1 C-SDK source-scope review

Status: **SCOPED SOURCE AND NOTICE EVIDENCE VERIFIED; NOT LEGAL CLEARANCE OR A PUBLICATION DECISION.**

## Evidence pins and method

- Matrix: `qualification/r1-hosted/preparation/csdk-licences/matrix.json`, SHA-256 `a8f7ad642cc497d1fb8aec540198673115b78dc76069f5410afb84d15767c3da`.
- SDK archive: SHA-256 `70cc3e45969c6e1eca7e4c5c2183429b88424f6c22c8ec6bb90e6cc70452ab87`; AROS source authority: commit `e0d5e367d15cc7da4ebac8f9db17868756c79569`.
- The 1,261 mapped AROS source paths and 1,413 mapped SDK-header paths were independently compared byte-for-byte and by SHA-256 with the pinned AROS-NX tree: **0 mismatches**.
- The matrix notice documents provide content hashes for root and nested AROS terms. The matrix is a provenance map; it does not itself classify every source license or generated output.
- No source/build was run. This review does not resolve rights beyond the supplied notices and mapped file contents.

## AROS source/header scope

The root [`LEGAL`](qualification/r1-hosted/preparation/csdk-licences/texts/aros/by-sha256/e4de7b47f775d91810f6f2a1c04fd9af8b722ab4328f67cd0616cce5901b3f39.txt) identifies APL 1.1 as the default and routes named components to separate terms. [`LICENSE.Author`](qualification/r1-hosted/preparation/csdk-licences/texts/aros/by-sha256/c0f27d937e026f643ef023a8a60940920a30839dc676675ce385b7ac14f911f2.txt) adds author-specific permissions; it does not replace the base license wholesale.

The mapped compiled-source inventory partitions exactly as follows:

| Count | Exact notice scope | File-scope conclusion |
|---:|---|---|
| 218 | Root `LICENSE`/`LEGAL` | APL-default group; embedded notices still govern where present. |
| 825 | `workbench/hidds/nouveau/LEGAL` | Mixed, per its exact rules below. |
| 105 | `compiler/crt/stdc/LEGAL` + `compiler/crt/stdc/math/LEGAL` | Mixed Sun, BSD/FreeBSD, Moshier and AROS notices; do not label this group uniformly APL. |
| 93 | `compiler/crt/stdc/LEGAL` | APL default; `memmove.c`, `strlcat.c`, and `strlcpy.c` have separate BSD notices. Four selected libnix-derived paths (`__vcformat.c`, `vsnprintf.c`, `vsprintf.c`, `vsscanf.c`) are expressly listed as APL in the LEGAL. |
| 8 | `compiler/crt/posixc/LEGAL` | Six selected files are APL-default; `getopt.c` has UC/Berkeley BSD terms and `getopt_long.c` has ISC-style plus NetBSD BSD terms. |
| 5 | `arch/all-pc/udis86/LICENSE` | BSD-style package terms. |
| 4 | `workbench/libs/muimaster/LICENSE` | APL 1.1. |
| 3 | `workbench/devs/USB/LICENSE.LGPL` | LGPL 2.1 scope; preserve license and source. |

The mapped header inventory partitions exactly as: 730 root-default; 497 Boost Software License 1.0; 71 POSIX-C; 56 stdc; 15 OpenURL; 12 public-domain SDI; 8 Zune nlist LGPL; 5 Zune TextEditor LGPL; 4 USB LGPL; 3 udis86; 3 FlexCat-path headers; 2 BetterString LGPL; 1 Poseidon header; 1 MUI master; and five individual Zune LGPL class headers. These counts sum to 1,413.

For Nouveau, 758 selected Linux DRM/Nouveau source files, eight TTM files and four DRM display files fall under the nested LEGAL's MIT or dual GPL-2.0/MIT rule with MIT selected; the tree contains no GPL-only source selected in this group. `drm-aros` sources are APL. The `drm-compat` source exceptions are exactly `linux_dma_fence.c`, `linux_dma_fence_array.c` (BSD-2-Clause), `linux_dma_resv.c` (MIT), `linux_idr.c` and `linux_compat.c` (BSD-2-Clause), and `linux_hdmi.c` (MIT). The seven GPL-only DRM headers listed by that LEGAL are AROS-authored replacement prototypes in the source tree; the upstream GPL-only `drm_dp_mst_topology_internal.h` is described as an APL prototype replacement. These replacement files are outside the mapped 1,413 SDK-header set, so include them only as AROS-source inputs if required by the full build closure.

For the CRT group, no `GCC Runtime Library Exception` or GPL runtime-exception text appears in the mapped CRT sources/notices. The 127 CRT header paths (71 POSIX-C + 56 stdc) and eight POSIX-C source paths account for the 135-item subset sometimes described as the compiler-runtime set; that count must not be interpreted as a GPL runtime-exception grant. The 105 math files include BSD/FreeBSD and Sun/Moshier source notices and sometimes include another `.c` file; the complete source closure must preserve those included files and their notices too.

## Vendor scope and required notices

| Package | Mapped archive C sources / SDK headers | Scope and required preservation |
|---|---:|---|
| ACPICA | 0 / 64 | Each header has embedded ACPICA/Intel notice blocks; independent readback preserved all 64 byte slices. `acaros.h` is AROS-specific. |
| bzip2 | 7 / 1 | Preserve its package LICENSE and mapped source/header files. |
| codesets | 1 / 11 | LGPL 2.1 (including AROS codesets component); preserve `COPYING`, `COPYING.info`, patched source, patch and build recipe. |
| Expat | 0 / 2 | Preserve Expat COPYING with the headers. |
| FreeType | 41 / 99 | Select FTL for FreeType files; preserve `LICENSE.TXT`, full FTL and applicable file-specific notices. BDF/PCF sources carry permissive MIT notices; gzip embeds zlib-licensed source; Autofit has explicit MIT-licensed files. The finalized corresponding-source capsule retains the original source archives and notices; no per-file licence clearance is asserted. |
| FTDemo | 9 / 0 | Nine compiled files and AROS patch are captured, but the slice receipt explicitly is not complete-source/license clearance. FTL applies to FreeType project files without another explicit license; `grswizzle.c` explicitly places its filtering code in the public domain. `grfont.c` embeds CP437 bitmap arrays with no separate data notice in that file; preserve the complete upstream demo source and FTL, and do not claim separate font-data provenance. |
| GLU | 0 / 1 | `Developer/include/GL/glu.h` contains an SGI Free Software License B 2.0 notice; the complete notice is preserved from the exact header slice. |
| IJG JPEG | 0 / 4 | Preserve the complete pinned `jpeg-9f/README` terms; independent readback saved all 18,719 bytes and all four header notice slices. |
| libaom | 68 / 0 | Select the BSD license and preserve full `LICENSE` and `PATENTS`. Preserve explicit patent grants and conditions; no broad patent-clearance conclusion follows. |
| libpng | 17 / 2 | Preserve the package LICENSE and exact source/header tree. |
| SoftFloat | 0 / 2 | Preserve `COPYING.txt` and exact extracted tree. The finalized capsule includes the original `SoftFloat-3e.zip` (SHA-256 `21130ce885d35c1fe73fc1e1bf2244178167e05c6747cad5f450cc991714c746`) and its extracted source tree. |
| libtiff | 0 / 1 | Preserve `LICENSE.md` with the exact header. |
| mbedTLS | 107 / 97 | Mapped files declare `Apache-2.0 OR GPL-2.0-or-later`; choose Apache-2.0 and retain its license text. No package NOTICE file is present in the extracted tree. |
| Mesa/Khronos | 0 / 12 | Mixed header-specific notices: eight permissive MIT/Chromium-style headers; four Vulkan headers (`vk_icd.h`, `vk_platform.h`, `vulkan.h`, `vulkan_core.h`) are Apache-2.0. The finalized capsule includes the full Apache-2.0 text (SHA-256 `cfc7749b96f63bd31c3c42b5c471bf756814053e847c10f3eb003417bc523d30`) and `evidence/vulkan-apache-2.0-scope.json` binds it to those four headers while disclaiming authorship/ownership. |
| utf8proc | 0 / 1 | Preserve `LICENSE.md`. |
| XZ/liblzma | 64 / 15 | All 64 direct sources and 15 headers are 0BSD within `src/liblzma`; package `COPYING` includes unrelated alternatives. Preserve per-file 0BSD IDs and package COPYING. |
| zlib/Chromium snapshot | 21 / 2 (42 archive member rows) | Preserve Chromium BSD notice plus zlib's license/source notices. The 1.2.12 banner is a stale version label, not an independent license mismatch; source bytes are from the pinned Chromium receipt. |
| zstd | 30 / 3 | Select BSD from dual BSD/GPLv2 notices; retain both package LICENSE and COPYING as supplied. |

Independent notice readback receipt `qualification/r1-hosted/preparation/notice-completion/independent-readback.json` reports byte-preserving readback for ACPICA (64), GLU (1), and IJG (4), with no package-wide clearance claim.

## Source-capsule readback

`release/csdk-source/manifest.json` pins the SDK input and records the corresponding-source capsule at 103,277,840 bytes, SHA-256 `7e62e28fb025e31aacdd3b6a6d14cef7d76703eb59dbaca02f2e2b4de68c6914`. Its readback reports all 33,043 members verified, totaling 418,962,351 regular-file bytes. The capsule includes the pinned AROS-NX and aros-tools source authorities, 18 original vendor archives (including SoftFloat), patches, recipes, generated inputs, and the scoped Vulkan license evidence. I independently checked the capsule hashes for the Apache text, its scope receipt, the SoftFloat and FTDemo original archives, and the Mesa archive against the manifest. This verifies source/notice-byte preservation only; it does not establish license clearance or reproducible native build equivalence.

## Cargo host prerequisite notices

The v2 Cargo-notice archive records the frozen Cargo source commit and lockfile, and readback reports 523 packages, 2,619 members, 13,456,280 expanded bytes, 2,054,268 compressed bytes, SHA-256 `c4bc295f4e4f4fce357245e56e66eb947601b108622a1cdc2b7e82a87b70bb50`. Its claim is notice and manifest preservation, not final license approval.

The previous source-availability concern for MPL packages is resolved at the evidence level: all source files for `im-rc 15.1.0` (48/48), `bitmaps 2.1.0` (11/11), and `sized-chunks 0.6.5` (27/27) are present in v2. I matched every file's SHA-256 to its included `.cargo-checksum.json` and each registry checksum to the locked Cargo package. The full MPL text is also present. Because Cargo's lockfile root directly lists `im-rc`, any external distribution of the produced Cargo executable should tell recipients how to obtain these MPL source files; the v2 archive provides a ready source path if shipped alongside the binary. This observation does not claim that every package in the lockfile is linked into either host executable.

A filename audit found 23 package archives with no separate `LICENSE*`, `LICENCE*`, `COPYING*`, `NOTICE*`, `COPYRIGHT*`, or `PATENTS*` file. The captured package metadata and README files remain in v2. The supplemental receipt pins 32 upstream license/readme files (70,385 bytes) for packages whose crate checksum, `.cargo_vcs_info.json` commit, and repository URL were available; raw bytes match pinned Git tree blobs. The exact `AUTHORS` file for both `r-efi` versions is captured and supplies the license text and copyright attribution.

The three previously unresolved target-specific source references are now independently bound in `cargo-upstream-evidence/reference-recovery.json`. For `rsqlite-vfs 0.1.1`, `.cargo_vcs_info.json` pins commit `1bb309784f25c401ddf95131dcde4c4cdad7aee7`; its `sqlite-wasm-rs` repository identity is confirmed by the commit API, the crate README, and exact Git-blob matches for its packaged source, manifest, and README. The crate archive omits its declared MIT `LICENSE`; the full text was recovered from the exact pinned repository `LICENSE` (1,061 bytes, SHA-256 `e1c1975c3474cce31722836f101a40ffaf1cc784e4d2f38ce3e77b9712934e78`). One packaged `Cargo.lock` has no tree counterpart and is recorded separately as auxiliary metadata.

For both Windows GNU import-library crates, the complete included payload matches files at immutable `winapi-rs` commit `9497609ef44cc9bcd16cd2411c0ee6ccaf5483aa`: 1,390/1,390 i686 files and 1,419/1,419 x86_64 files, excluding only Cargo's generated normalized `Cargo.toml`. `Cargo.toml.orig` and `build.rs` match exactly. The commit's full `LICENSE-MIT` (1,068 bytes) and `LICENSE-APACHE` (11,357 bytes) are preserved with Git-blob and SHA-256 receipts. This establishes byte provenance, not a signed tag or legal clearance. These packages target Windows; the wasm/Windows target labels do not establish inclusion in a specific host binary.

For the pinned objc2 crates, four immutable source trees contain `LICENSE.md` but no standalone MIT, Apache-2.0, or zlib license-text files. The exact scope document identifies per-crate license choices, links to the standard texts, and retains the upstream Apple-SDK-derived-code caveat. The Cargo v2 archive contains no license file for these crates. Treat the file as a scope statement, not the full license text or a legal conclusion. The standard license texts and any required copyright attribution still need to appear in a final external distribution record.

For Cargo's produced binaries, retain the actual dependency-specific notices in the accompanying distribution. The archive captures the current OpenSSL 3.6.3 source license (`openssl-src`'s bundled `openssl/LICENSE.txt`) as well as the Cargo project `LICENSE-THIRD-PARTY` and transitive native-library notice files. Do not infer linked membership solely from `Cargo.lock`; the capture intentionally includes optional and foreign-target packages.

## Gate boundary

This review establishes scoped source and notice evidence only. It is not a legal opinion, complete final license approval, runtime-link inventory, or publication authorization. The recovered rsqlite/winapi references are not identified blockers for the host prerequisite build. The objc2 license-text packaging gap remains a final distribution item; assess it together with the actual host-binary link inventory. The separate generated-path boundary and full SDK publication/signing gates remain outside this review.
