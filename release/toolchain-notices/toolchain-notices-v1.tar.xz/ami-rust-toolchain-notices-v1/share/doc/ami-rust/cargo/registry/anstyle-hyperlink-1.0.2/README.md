# anstyle-hyperlink

> ANSI escape code hyperlinks (OSC 8)

[![Documentation](https://img.shields.io/badge/docs-master-blue.svg)][Documentation]
![License](https://img.shields.io/crates/l/anstyle-hyperlink.svg)
[![Crates Status](https://img.shields.io/crates/v/anstyle-hyperlink.svg)](https://crates.io/crates/anstyle-hyperlink)

## License

Licensed under either of

* Apache License, Version 2.0, ([LICENSE-APACHE](LICENSE-APACHE) or <https://www.apache.org/licenses/LICENSE-2.0>)
* MIT license ([LICENSE-MIT](LICENSE-MIT) or <https://opensource.org/license/mit>)

at your option.

## [Contribute](../../CONTRIBUTING.md)

Unless you explicitly state otherwise, any contribution intentionally
submitted for inclusion in the work by you, as defined in the Apache-2.0
license, shall be dual-licensed as above, without any additional terms or
conditions.

[Crates.io]: https://crates.io/crates/anstyle-hyperlink
[Documentation]: https://docs.rs/anstyle-hyperlink
