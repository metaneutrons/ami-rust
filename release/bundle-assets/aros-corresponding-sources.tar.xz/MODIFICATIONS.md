# AROS Covered Code and modifications

Original Code: AROS Development Team and original contributors, pinned AROS-NX
commit e0d5e367d15cc7da4ebac8f9db17868756c79569. Covered source and modifications
remain under AROS Public License 1.1, reproduced in LICENSE. Original notices
and applicable nested LEGAL files are preserved. No new patent claim is known.

2026-10-14: ami-rust derives six Rust ABI declaration groups from the original
headers; their source and modification record are in the accompanying SDK,
crates/aros-sys. The SDK producer renames only the stock startup object's
__startup_entry symbol to ami_sdk_startup_entry before linking; the original
startup C source and host producer recipe are supplied.

2026-10-15: detached source packaging changes only generated-comment
private source-root prefixes, as enumerated in modifications.json. No compiled
statement is changed. All other supplied AROS files retain their original bytes.

The source version of AROS Covered Code is provided on the same media as the
native reference executable in this archive and the SDK source archive. Use
widely available xz/tar tools to extract both. Original and generated associated
headers, library sources, genmodule sources/configuration and build-rule inputs
are included. Qualified external compiler/toolchain prerequisites remain in the
compatibility inventory. Local historical generator execution logs were not
retained; this capsule does not invent them or claim a new reproducible C build.
