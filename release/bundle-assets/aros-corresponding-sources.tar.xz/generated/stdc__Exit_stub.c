/*
    *** Automatically generated from 'AROS-NX/compiler/crt/stdc/stdc.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/
#ifdef  NOLIBINLINE
#undef  NOLIBINLINE
#endif  /* NOLIBINLINE */
#ifdef  NOLIBDEFINES
#undef  NOLIBDEFINES
#endif  /* NOLIBDEFINES */
#define NOLIBINLINE
#define NOLIBDEFINES
/* Be sure that the libbases are included in the stubs file */
#ifdef  __NOLIBBASE__
#undef  __NOLIBBASE__
#endif  /* __NOLIBBASE__ */
#ifdef  __STDC_NOLIBBASE__
#undef  __STDC_NOLIBBASE__
#endif  /* __STDC_NOLIBBASE__ */

#define STDC_NOINLINE

#include <proto/stdc.h>
#include <stddef.h>

#include <aros/cpu.h>
#include <aros/genmodule.h>
#include <aros/libcall.h>
#include <aros/symbolsets.h>

void ___Exit_StdCBase_libreq(){ AROS_LIBREQ(StdCBase,0); }
AROS_GM_LIBFUNCSTUB(_Exit, StdCBase, 336)
AROS_GM_LIBFUNCALIAS(_Exit, _exit)
