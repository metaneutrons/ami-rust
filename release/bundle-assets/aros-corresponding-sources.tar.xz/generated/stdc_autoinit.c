#include "stdc_startup.c"
/*
    *** Automatically generated from 'AROS-NX/compiler/crt/stdc/stdc.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <proto/stdc.h>
#include <aros/symbolsets.h>

AROS_LIBSET("stdc.library", struct StdCBase *, StdCBase)
AROS_IMPORT_ASM_SYM(int, dummy, __includelibrarieshandling);
