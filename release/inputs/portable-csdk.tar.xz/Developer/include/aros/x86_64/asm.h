/* Macros */
#define AROS_CSYMNAME(n)       n
#define AROS_CDEFNAME(n)       n
#define AROS_SLIB_ENTRY(n,s,o)   s ## _ ## o ## _ ## n
#define _FUNCTION(n)           .type   n,@function
#define _ALIGNMENT             .balign 16
/* ExecBase */
#define AttnResched 706 
#define AttnFlags 704 
#define IDNestCnt 702 
#define TDNestCnt 703 
#define TaskReady 944 
#define TaskWait 976 
#define ThisTask 680 
#define SysFlags 700 
#define IdleCount 688 
#define DispCount 692 
#define Quantum 696 
#define Elapsed 698 
#define SysStkUpper 232 
/* struct Task */
#define tc_State 33 
#define tc_Flags 32 
#define tc_ExceptCode 72 
#define tc_ExceptData 64 
#define tc_SigExcept 48 
#define tc_SigWait 40 
#define tc_SigRecvd 44 
#define tc_Launch 128 
#define tc_Switch 120 
#define tc_SPReg 96 
#define tc_SPLower 104 
#define tc_SPUpper 112 
#define tc_IDNestCnt 34 
#define tc_TDNestCnt 35 
#define tc_ETask 56 
/* struct ETask */
#define et_Reserved 320 
#define et_RegFrame 336 
/* struct Process */
#define pr_CES 712 
#define pr_CIS 576 
#define pr_CLI 608 
#define pr_COS 584 
#define pr_CurrentDir 568 
#define pr_ConsoleTask 592 
#define pr_FileSystemTask 600 
#define pr_MsgPort 304 
#define pr_Result2 560 
#define pr_ReturnAddr 616 
#define pr_SegList 520 
#define pr_WindowPtr 632 
/* struct DosBase */
#define dl_Root 192 
#define dl_TimeReq 240 
#define dl_UtilityBase 248 
#define dl_IntuitionBase 256 
/* struct DosPacket */
#define dp_Link 0 
#define dp_Port 8 
#define dp_Type 16 
#define dp_Res1 24 
#define dp_Res2 32 
#define dp_Arg1 40 
#define dp_Arg2 48 
#define dp_Arg3 56 
#define dp_Arg4 64 
#define dp_Arg5 72 
#define dp_Arg6 80 
#define dp_Arg7 88 
/* struct FileHandle */
#define fh_Flags 0 
#define fh_Interactive 4 
#define fh_Type 8 
#define fh_Buf 16 
#define fh_Pos 24 
#define fh_End 28 
/* struct IORequest */
#define io_Message 0 
#define io_Device 48 
#define io_Unit 56 
#define io_Command 64 
#define io_Flags 66 
#define io_Error 67 
/* struct timerequest */
#define tr_time 72 
/* struct MsgPort */
#define mp_SigTask 40 
/* struct StackSwapStruct */
#define stk_Lower 0 
#define stk_Upper 8 
#define stk_Pointer 16 
/* struct Layer */
#define ly_Lock 136 
/* Task Flags */
#define TS_RUN 2 
#define TS_READY 3 
#define TS_WAIT 4 
#define TF_STACKCHK 16 
#define TF_EXCEPT 32 
#define TF_SWITCH 64 
#define TF_LAUNCH 128 
#define TF_DISPATCH_SPECIAL 160 
/* Exec Flags */
#define AFF_FPU 32768 
#define SFF_QuantumClear -8193 
/* Exec functions */
#define Supervisor -40 
#define Reschedule -64 
#define Switch -72 
#define Dispatch -80 
#define Exception -88 
#define Alert -144 
#define Disable -160 
#define Enable -168 
#define Enqueue -360 
#define FindTask -392 
#define ObtainSemaphore -752 
#define ReleaseSemaphore -760 
#define AttemptSemaphore -768 
#define StackSwap -976 
/* Constants */
#define AT_DeadEnd -2147483648 
#define AN_StackProbe 16777230 
#define ln_Succ 0 
#define ln_Pred 8 
#define ln_Pri 17 
#define ln_Name 24 
#define lh_Head 0 
#define lh_TailPred 16 
/* CPU context */
#define ECF_SEGMENTS 1 
#define Flags 0 
#define reg_ds 128 
#define reg_es 136 
#define reg_fs 144 
#define reg_gs 152 
#define UseExecstubs 1
/* jmp_buf */
#define jmpbuf_SIZEOF 128 
#define retaddr 0 
