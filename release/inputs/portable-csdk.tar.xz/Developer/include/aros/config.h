/* AROS-NX v0.1.0: Auto-generated aros/config.h */
#ifndef AROS_CONFIG_H
#define AROS_CONFIG_H

#define AROS_FLAVOUR_NATIVE             1
#define AROS_FLAVOUR_STANDALONE         2
#define AROS_FLAVOUR_EMULATION          4
#define AROS_FLAVOUR_LINKLIB            8
#define AROS_FLAVOUR_BINCOMPAT          16
#define AROS_FLAVOUR                    AROS_FLAVOUR_STANDALONE
#define AROS_DOS_PACKETS                1
#define AROS_AMIGAOS_COMPLIANCE         1

/* Public ABI padding; this does not enable the SMP execution path. */
#define __AROSPLATFORM_SMP__

#define AROS_NOMINAL_WIDTH              640
#define AROS_NOMINAL_HEIGHT             480
#define AROS_NOMINAL_DEPTH              8

#define AROS_SERIAL_DEBUG               1
#define AROS_MODULES_DEBUG              1

#endif /* AROS_CONFIG_H */
