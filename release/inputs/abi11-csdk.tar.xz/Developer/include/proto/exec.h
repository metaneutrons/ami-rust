#ifndef PROTO_EXEC_H
#define PROTO_EXEC_H

/*
    *** Automatically generated from '/ssd/deadwood/repo-github-dd-core-release/AROS/rom/exec/exec.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/exec_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__EXEC_NOLIBBASE__)
  #if !defined(SysBase)
   #ifdef __EXEC_STDLIBBASE__
    extern struct Library *SysBase;
   #else
    extern struct ExecBase *SysBase;
   #endif
  #endif
 #endif
 #ifndef __EXEC_LIBBASE
  #define __EXEC_LIBBASE (SysBase)
 #endif
#ifndef __aros_getbase_SysBase
extern struct ExecBase *__aros_getbase_SysBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(EXEC_NOLIBINLINE)
# include <inline/exec.h>
#elif !defined(NOLIBDEFINES) && !defined(EXEC_NOLIBDEFINES)
# include <defines/exec.h>
#endif

#endif /* PROTO_EXEC_H */
