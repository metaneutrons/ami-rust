#ifndef PROTO_DOS_H
#define PROTO_DOS_H

/*
    *** Automatically generated from '/ssd/deadwood/repo-github-dd-core-release/AROS/rom/dos/dos.conf'. Edits will be lost. ***
    Copyright (C) 1995-2026, The AROS Development Team. All rights reserved.
*/

#include <exec/types.h>
#include <aros/system.h>

#include <clib/dos_protos.h>

 #if !defined(__NOLIBBASE__) && !defined(__DOS_NOLIBBASE__)
  #if !defined(DOSBase)
   #ifdef __DOS_STDLIBBASE__
    extern struct Library *DOSBase;
   #else
    extern struct DosLibrary *DOSBase;
   #endif
  #endif
 #endif
 #ifndef __DOS_LIBBASE
  #define __DOS_LIBBASE (DOSBase)
 #endif
#ifndef __aros_getbase_DOSBase
extern struct DosLibrary *__aros_getbase_DOSBase(void);
#endif

#if !defined(NOLIBINLINE) && !defined(DOS_NOLIBINLINE)
# include <inline/dos.h>
#elif !defined(NOLIBDEFINES) && !defined(DOS_NOLIBDEFINES)
# include <defines/dos.h>
#endif

#endif /* PROTO_DOS_H */
