# C-SDK corresponding-source capsule

This capsule preserves source and input evidence for the frozen C-SDK archive
with SHA-256 `70cc3e45969c6e1eca7e4c5c2183429b88424f6c22c8ec6bb90e6cc70452ab87` (5621776 bytes; 2,835 regular SDK files).

It includes the complete regular source trees at AROS-NX commit `e0d5e367d15cc7da4ebac8f9db17868756c79569`
and aros-tools commit `b399c714560e6629b4084290ce5575513521c8e3`, the exact SDK archive, per-member source
mapping, generated producer sources, configured public headers, the generator
release asset, original vendor source archives, patch references, and preserved
notice/license bytes. All timestamps and ownership in the capsule are fixed.

This is a corresponding-source preservation result. It is not a licence grant,
licence-scope determination, build reproduction, or release authorization.
The notice matrix and unresolved scope findings are in `evidence/`; root legal
and release review remains necessary. The exact original source archive for
each of the 18 vendor packages is included with receipt-bound SHA-256.

The 75 AROS Git links are enumerated in `evidence/gitlink-exclusions.json`.
Their source trees are not copied; no direct C-SDK source or generated-header
input mapped by the available receipts falls under those gitlink prefixes.
